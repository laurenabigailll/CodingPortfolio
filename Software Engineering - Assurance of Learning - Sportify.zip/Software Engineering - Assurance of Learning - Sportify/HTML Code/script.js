document.querySelector('.other-sports').addEventListener('click', function() {
    window.location.href = 'search.html'; /* Change to the search page URL */
});
