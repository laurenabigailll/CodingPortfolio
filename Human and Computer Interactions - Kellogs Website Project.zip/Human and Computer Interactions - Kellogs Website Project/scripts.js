// Form validation for the contact page
document.addEventListener("DOMContentLoaded", function() {
    const contactForm = document.querySelector("#contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", function(event) {
            let valid = true;
            
            const firstName = document.querySelector("#firstName");
            const lastName = document.querySelector("#lastName");
            const email = document.querySelector("#email");
            const phone = document.querySelector("#phone");
            const inquiry = document.querySelector("#inquiry");

            if (firstName.value.trim() === "") {
                valid = false;
                alert("First name is required.");
            }

            if (lastName.value.trim() === "") {
                valid = false;
                alert("Last name is required.");
            }

            if (email.value.trim() === "" || !email.value.includes("@")) {
                valid = false;
                alert("A valid email address is required.");
            }

            if (phone.value.trim() === "" || isNaN(phone.value) || phone.value.length < 10) {
                valid = false;
                alert("A valid phone number is required.");
            }

            if (inquiry.value.trim() === "") {
                valid = false;
                alert("Please specify the nature of your inquiry.");
            }

            if (!valid) {
                event.preventDefault();
            }
        });
    }
});
